# Junat.net WebView
A webview for junat.net. You can save stations as bookmarks.

Available on OpenRepos and Jolla Store

https://openrepos.net/content/jollailija/junatnet-webview 
