<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>BookmarkPage</name>
    <message>
        <source>Bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>No bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Pull down to add current page to bookmarks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Warning: deleting is instant</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Add current page to bookmarks:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Nothing was found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Try a different search term</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FirstPage</name>
    <message>
        <source>Current page:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Smaller font (text won&apos;t overlap)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Bigger font (text may overlap)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Junat.net WebView version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Hide navigation bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Open navigation bar</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Help</name>
    <message>
        <source></source>
        <translation></translation>
    </message>
</context>
</TS>
