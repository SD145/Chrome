package nav.library.new23db.constant;

/**
 * Created by abhin on 4/4/2017.
 */

public abstract class DatabaseConstant {
    public static final String DBNANME="Projects.db";

    public static final int DATABASE_VERSION=1;

    public static final String DBPATH="/data/data/";

    public static final String TAG="DatabaseHelper";
}
